<?php
 echo "SORRY.......The seat is already booked. Select the blue seats only ";
?>
