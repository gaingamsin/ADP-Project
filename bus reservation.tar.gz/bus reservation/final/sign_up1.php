<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
    <title> Airbus Sign-up</title>
    <link rel="stylesheet" type="text/css" href="air.css">
  </head>

  <body>
    <div class="page">
     <div class="top">
  <img src="aaa1.png" width="150" height="100" title="airbus logo">
  <p><i>The way travelling meant to be...</i></p>
</div>

<!--div class="iit_image ">
  <img src="iit.jpg" width="150" height="116" title="iitmandi logo" alt="iitmandi">
</div-->

<div class="iit">
  <center>
    <p class="text1">INDIAN INSTITUTE OF TECHNOLOGY</p>
  <p class="text2">Mandi-Kamand, Himachal Pradesh (175005)</p>
  <p class="text3">Portal For Bus Services In IIT Mandi</p>
  </center>
</div>

    <ul>
  <li><a href="airbus.php">Log-in</a></li>
  <li><a href="sugg1.php">Suggestion</a></li>
  <li><a href="contact1.php">Contact</a></li>
  <li><a href="about1.php">About</a></li>
  <li><a class="active" href="sign_up.php">Sign up</a></li>
</ul>

    <div class="wrapper">

  <form class="login" method="POST" action="sign.php">
  	<p><img src="aaa.png" width="250" height="150" title="airbus logo" alt="airbus logo"></p>
    <p class="title">Sign up Here</p>
    <p class="credential">Name</p>
    <input type="text" name="name" placeholder="Full Name" required autofocus/> 
    <p class="credential">Choose a Username</p>
    <input type="text" name="uname" placeholder="Choose a user name of single word" required> 
    <p class="credential">Choose a Password</p>
    <input type="password" name="psw" placeholder="Choose a password" required> 
    <p class="credential">Enter E-mail</p>
    <input type="email" name="mail" placeholder="E-mail ID" required>   
    <button>Sign up</button>
  </form>
  
  
</div>
</div>
  </body>
</html>
