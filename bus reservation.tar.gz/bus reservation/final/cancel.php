<!DOCTYPE html>
<html>
  <head>
    <title> Login to Airbus services</title>
     <meta http-equiv="refresh" content="500" />
    <link rel="stylesheet" type="text/css" href="air.css">

  </head>

  <body>
    <div class="page">

<div class="top">
  <img src="aaa1.png" width="150" height="100" title="airbus logo">
  <p><i>The way travelling meant to be...</i></p>
</div>

<!--div class="iit_image ">
  <img src="iit.jpg" width="150" height="116" title="iitmandi logo" alt="iitmandi">
</div-->

<div class="iit">
  <center>
    <p class="text1">INDIAN INSTITUTE OF TECHNOLOGY</p>
  <p class="text2">Mandi-Kamand, Himachal Pradesh (175005)</p>
  <p class="text3">Portal For Bus Services In IIT Mandi</p>
  </center>
</div>




    <div class="wrapper">
  <form class="login" method="POST" action="cancel1.php">
  	<p><img src="aaa.png" width="250" height="150" title="airbus logo" alt="airbus logo"></p>
    
    <input type="text" name="uname" placeholder="Username" required autofocus/>
    
      
    <button name="submit_pass">Log in</button>
      
  </form>
  
  
</div>
</div>
  </body>
</html>
