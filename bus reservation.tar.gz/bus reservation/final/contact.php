<!DOCTYPE html>
<html>
  <head>
    <title>About the site</title>
    
     <link rel="stylesheet" type="text/css" href="air.css">

  </head>

  <body>
    <div class="page">
 <div class="top">
  <img src="aaa1.png" width="150" height="100" title="airbus logo">
  <p><i>The way travelling meant to be...</i></p>
</div>

<!--div class="iit_image ">
  <img src="iit.jpg" width="150" height="116" title="iitmandi logo" alt="iitmandi">
</div-->

<div class="iit">
  <center>
    <p class="text1">INDIAN INSTITUTE OF TECHNOLOGY</p>
  <p class="text2">Mandi-Kamand, Himachal Pradesh (175005)</p>
  <p class="text3">Portal For Bus Services In IIT Mandi</p>
  </center>
</div>
  <ul>
  <li><a href="home.php">Home</a></li>
  <li><a href="status.php">Status</a></li>
  <li><a href="enquiry.php">Enquiry</a></li>
  <li><a href="sugg.php">Suggestion</a></li>
  <li><a class="active" href="contact.php">Contact</a></li>
  <li><a href="about.php">About</a></li>
  <li><a class="sign" href="airbus.php">Log out</a></li>
  
</ul>
</div>

  
</div>


<div class="wrapper1">
  <form class="login" method="POST" action="https://www.facebook.com/jonty.purbia">
    <p><img src="jp.jpg" width="250" height="250" title="jonty purbia" alt="airbus logo"></p>
    <p class="title">Jonty purbia<br>Contact no.:+91-7018498822</p>
    <button name="submit_pass">Find Jonty on facebook</button>
   </form>
</div>


<div class="wrapper1">
  <form class="login" method="POST" action="https://www.facebook.com/jonty.purbia">
    <p><img src="gp.jpg" width="250" height="250" title="Gaingamsin Pamei" alt="sammy"></p>
    <p class="title">Gaingamsin<br>Contact no.:+91-8894562776</p>
    <button name="submit_pass">Find Gaingamsin on facebook</button>
   </form>
</div>



<div class="wrapper1">
  <form class="login" method="POST" action="https://www.facebook.com/pramod.jonwal.5">
    <p><img src="pj.jpg" width="250" height="250" title="jonwal" alt="sammy"></p>
    <p class="title">Pramod Jonwal<br>Contact no.:+91-9882651216</p>
    <button name="submit_pass">Find Jonwal on facebook</button>
   </form>
</div>




<div class="wrapper1">
  <form class="login" method="POST" action="https://www.facebook.com/pramod.jonwal.5">
    <p><img src="ak.jpg" width="250" height="250" title="Gaingamsin Pamei" alt="sammy"></p>
    <p class="title">Avnish Kumar<br>Contact no.:+91-9736315558</p>
    <button name="submit_pass">Find Avnish on facebook</button>
   </form>
</div>
     
    
      

</div>

<div class="contactc">
  <p><b>NOTE</b>: Do not reveal any information that you or others might deem confidential</p>

</div>
  </body>
</html>