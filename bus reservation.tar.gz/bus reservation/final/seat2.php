<?php
 echo "SORRY.......The seat is reserved for FACULTIES only.Select the other blue seats ";
?>
